﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Algoritma_Analizi
{
    public partial class AnaSayfa : Form
    {
        public AnaSayfa(string kullaniciAdi)
        {
            InitializeComponent();
            // Gelen kullanıcı adını lblHosgeldiniz Label'ına yazdırıyoruz
            lblHosgeldiniz.Text = $"Hoş geldiniz, {kullaniciAdi}!";
        }
        private void AnaSayfa_Load(object sender, EventArgs e)
        {

        }
    }
}
